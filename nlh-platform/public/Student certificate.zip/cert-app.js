/* ============================================================
   NLH Certificate — cert-app.js
   ============================================================ */

const $ = id => document.getElementById(id);
const $q = sel => document.querySelector(sel);

/* ── Programs quick-pick ── */
const PROGRAMS = [
  { e: "🧮", n: "A.C.E.M Abacus" },
  { e: "✍️", n: "Write Well" },
  { e: "💻", n: "Coding" },
  { e: "🎲", n: "Rubik's Cube" },
  { e: "🔤", n: "Phonics" },
  { e: "🎨", n: "Art & Craft" },
  { e: "📖", n: "Storytelling" },
  { e: "🎭", n: "Public Speaking" },
  { e: "➗", n: "Easy Math" },
];

const chipsEl = $("program-chips");
PROGRAMS.forEach(p => {
  const c = document.createElement("button");
  c.className = "chip";
  c.type = "button";
  c.textContent = `${p.e} ${p.n}`;
  c.dataset.name = p.n;
  c.addEventListener("click", () => {
    chipsEl.querySelectorAll(".chip").forEach(x => x.classList.remove("active"));
    c.classList.add("active");
    $("f-program").value = p.n;
    render();
  });
  chipsEl.appendChild(c);
});
// mark initial active
const initChip = [...chipsEl.querySelectorAll(".chip")].find(c => c.dataset.name === $("f-program").value);
if (initChip) initChip.classList.add("active");

/* ── Date formatter  DD.MM.YYYY ── */
function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso + "T12:00:00");
  if (isNaN(d)) return iso;
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${dd}.${mm}.${d.getFullYear()}`;
}

/* ── Live render ── */
function render() {
  const title   = $("f-title").value.trim();
  const name    = $("f-name").value.trim();
  const rel     = $("f-rel").value.trim();
  const parent  = $("f-parent").value.trim();
  const loc     = $("f-location").value.trim();
  const prog    = $("f-program").value.trim();
  const level   = $("f-level").value.trim();
  const center  = $("f-center").value.trim();
  const date    = $("f-date").value;
  const certid  = $("f-id").value.trim();

  // Name line
  const fullName = [title, name].filter(Boolean).join(" ");
  $("c-name").textContent = fullName;

  // Body
  $("c-parent").textContent  = `${rel} ${parent}, R/o. ${loc}`;
  $("c-program").textContent = level ? `${prog} — ${level}` : prog;
  $("c-center").textContent  = center;

  // Date & ID
  $("c-date").textContent   = fmtDate(date);
  $("c-certid").textContent = certid;

  // Auto-shrink name if too wide
  autoSizeName();
}

function autoSizeName() {
  const el = $("c-name");
  const maxW = 1840; // available width at native cert scale (2000 - 80 - 80)

  // Get the current CSS transform scale of the preview wrapper
  // getBoundingClientRect returns scaled px, so we divide by scale to get cert-native px
  function getScale() {
    const scaler = $q(".preview-scaler");
    if (!scaler) return 1;
    const m = (scaler.style.transform || "").match(/scale\(([0-9.]+)\)/);
    return m ? parseFloat(m[1]) : 1;
  }

  // Measure actual rendered text width using a Range
  const range = document.createRange();
  range.selectNodeContents(el);
  function textW() {
    const rect = range.getBoundingClientRect();
    return rect.width / getScale();
  }

  let size = 110;
  el.style.fontSize = size + "px";
  el.style.whiteSpace = "nowrap";

  // Keep shrinking until text fits or hits the floor
  while (textW() > maxW && size > 60) {
    size -= 3;
    el.style.fontSize = size + "px";
  }
}

// Wire all inputs
["f-title","f-name","f-rel","f-parent","f-location","f-program","f-level","f-center","f-date","f-id"]
  .forEach(id => {
    const el = $(id);
    if (el) { el.addEventListener("input", render); el.addEventListener("change", render); }
  });

render();

/* ── Preview scaling ── */
function fitPreview() {
  const stage   = $q(".preview-stage");
  const scaler  = $q(".preview-scaler");
  if (!stage || !scaler) return;
  const certW = 2000, certH = 1414;
  const availW = stage.clientWidth  - 48;   // 24px padding each side
  const availH = Math.max(window.innerHeight - 280, 500);
  const scale  = Math.min(availW / certW, availH / certH, 1);
  scaler.style.transform = `scale(${scale})`;
  // set the scaler's rendered box so the stage knows how tall to be
  scaler.style.width     = certW + "px";
  scaler.style.height    = certH + "px";
  stage.style.minHeight  = Math.round(certH * scale + 48) + "px";
}
window.addEventListener("resize", fitPreview);
fitPreview();

/* ── Toast ── */
function toast(msg, dur = 2600) {
  const t = $("toast");
  $("toast-msg").textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), dur);
}

/* ── Print ── */
$("btn-print").addEventListener("click", () => window.print());

/* ── Download PNG ── */
$("btn-download").addEventListener("click", async () => {
  const cert   = $("cert");
  const scaler = $q(".preview-scaler");
  // Temporarily restore 1:1 scale for capture
  const prev = scaler.style.transform;
  scaler.style.transform = "scale(1)";
  await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
  try {
    const dataUrl = await htmlToImage.toPng(cert, {
      width: 2000,
      height: 1414,
      pixelRatio: 1,
      cacheBust: true,
    });
    const a = document.createElement("a");
    const safeName = ($("f-name").value || "certificate")
      .replace(/[^a-z0-9 \-]/gi, "")
      .trim()
      .replace(/\s+/g, "-");
    a.download = `NLH-Certificate-${safeName}.png`;
    a.href = dataUrl;
    a.click();
    toast("Certificate saved as PNG");
  } catch (err) {
    console.error(err);
    toast("Download failed — use Print → Save as PDF instead");
  } finally {
    scaler.style.transform = prev;
  }
});

/* ── Email modal ── */
const modal = $q(".modal-overlay");
$("btn-email").addEventListener("click",  () => modal.classList.add("open"));
$("em-cancel").addEventListener("click",  () => modal.classList.remove("open"));
modal.addEventListener("click", e => { if (e.target === modal) modal.classList.remove("open"); });
$("em-send").addEventListener("click", () => {
  const to = $("em-to").value.trim();
  modal.classList.remove("open");
  toast(`Certificate emailed to ${to || "student"}`);
});
