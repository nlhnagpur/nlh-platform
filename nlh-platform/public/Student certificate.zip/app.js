/* ============================================================
   NLH Certificate — page logic
   ============================================================ */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* ---------- program quick-pick chips ---------- */
const PROGRAMS = [
  { emoji: "🧮", name: "A.C.E.M Abacus" },
  { emoji: "✍️", name: "Write Well" },
  { emoji: "💻", name: "Coding" },
  { emoji: "🎲", name: "Rubik's Cube" },
  { emoji: "🔤", name: "Phonics" },
  { emoji: "🎨", name: "Art & Craft" },
  { emoji: "📖", name: "Storytelling" },
  { emoji: "🎭", name: "Public Speaking" },
  { emoji: "➗", name: "Easy Math" },
];

const chipsHost = $("#program-chips");
PROGRAMS.forEach(p => {
  const c = document.createElement("button");
  c.className = "chip";
  c.type = "button";
  c.innerHTML = `<span>${p.emoji}</span><span>${p.name}</span>`;
  c.dataset.name = p.name;
  c.addEventListener("click", () => {
    $$(".chip", chipsHost).forEach(x => x.classList.remove("active"));
    c.classList.add("active");
    $("#f-program").value = p.name;
    render();
  });
  chipsHost.appendChild(c);
});
// mark first chip active to match initial state
const initial = $$(".chip", chipsHost).find(c => c.dataset.name === $("#f-program").value);
if (initial) initial.classList.add("active");

/* ---------- live render ---------- */
function fmtDate(isoStr) {
  if (!isoStr) return "";
  const d = new Date(isoStr);
  if (isNaN(d)) return isoStr;
  const day = String(d.getDate()).padStart(2, "0");
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${day} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function render() {
  const title = $("#f-title").value.trim();
  const name  = $("#f-name").value.trim();
  const rel   = $("#f-rel").value.trim();
  const par   = $("#f-parent").value.trim();
  const loc   = $("#f-location").value.trim();
  const prog  = $("#f-program").value.trim();
  const lvl   = $("#f-level").value.trim();
  const ctr   = $("#f-center").value.trim();
  const date  = $("#f-date").value;
  const sig   = $("#f-signatory").value.trim();
  const role  = $("#f-role").value.trim();
  const cid   = $("#f-id").value.trim();

  $("#c-name").textContent = [title, name].filter(Boolean).join(" ");
  $("#c-parent").textContent = `${rel} ${par}, R/o. ${loc}`;
  $("#c-program").textContent = lvl ? `${prog} — ${lvl}` : prog;
  $("#c-center").textContent = ctr;
  $("#c-signatory").textContent = sig;
  $("#c-role").textContent = role;
  $("#c-date").textContent = fmtDate(date);
  $("#c-id").textContent = cid;
  $("#c-id-mini").textContent = cid;

  // auto-fit name: shrink font-size if it gets too wide
  const nameEl = $("#c-name");
  nameEl.style.fontSize = "132px";
  // measure
  const cert = $("#cert");
  const maxWidth = 1180;
  let size = 132;
  while (nameEl.scrollWidth > maxWidth && size > 60) {
    size -= 4;
    nameEl.style.fontSize = size + "px";
  }
}

["f-title","f-name","f-rel","f-parent","f-location","f-program","f-level","f-center","f-date","f-signatory","f-role","f-id"]
  .forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener("input", render);
    el.addEventListener("change", render);
  });

render();

/* ---------- preview scaling ---------- */
function fitPreview() {
  const stage = $("#preview-stage");
  const scaleEl = $("#preview-scale");
  if (!stage || !scaleEl) return;
  // intrinsic cert width
  const intrinsicW = 1500;
  const intrinsicH = 1060;
  const stageW = stage.clientWidth - 56; // padding
  const stageMaxH = Math.max(window.innerHeight - 260, 480);
  const scale = Math.min(stageW / intrinsicW, stageMaxH / intrinsicH, 1);
  scaleEl.style.transform = `scale(${scale})`;
  // make stage tall enough to hold scaled cert
  scaleEl.style.height = (intrinsicH * scale) + "px";
  scaleEl.style.width  = intrinsicW + "px";
  stage.style.minHeight = (intrinsicH * scale + 56) + "px";
}
window.addEventListener("resize", fitPreview);
fitPreview();

/* ---------- toast ---------- */
function toast(msg) {
  const t = $("#toast");
  $("#toast-msg").textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2400);
}

/* ---------- actions ---------- */
$("#btn-print").addEventListener("click", () => {
  window.print();
});

$("#btn-download").addEventListener("click", async () => {
  const cert = $("#cert");
  // capture at native size — temporarily unscale the wrapper
  const scaleEl = $("#preview-scale");
  const prevTransform = scaleEl.style.transform;
  scaleEl.style.transform = "scale(1)";
  await new Promise(r => requestAnimationFrame(r));
  try {
    const dataUrl = await htmlToImage.toPng(cert, {
      width: 1500,
      height: 1060,
      pixelRatio: 2,
      cacheBust: true,
      backgroundColor: "#C6E4FB",
    });
    const a = document.createElement("a");
    const safeName = ($("#f-name").value || "certificate").replace(/[^a-z0-9 \-]/gi, "").trim().replace(/\s+/g, "-");
    a.download = `NLH-Certificate-${safeName}.png`;
    a.href = dataUrl;
    a.click();
    toast("Certificate downloaded");
  } catch (err) {
    console.error(err);
    toast("Download failed — try Print → Save as PDF");
  } finally {
    scaleEl.style.transform = prevTransform;
  }
});

const modal = $("#email-modal");
$("#btn-email").addEventListener("click", () => modal.classList.add("open"));
$("#em-cancel").addEventListener("click", () => modal.classList.remove("open"));
modal.addEventListener("click", e => { if (e.target === modal) modal.classList.remove("open"); });
$("#em-send").addEventListener("click", () => {
  const to = $("#em-to").value.trim();
  modal.classList.remove("open");
  toast(`Certificate emailed to ${to || "student"}`);
});

/* ---------- decorative bottom band (children silhouettes) ---------- */
(function buildBand() {
  const band = $("#bottom-band");
  if (!band) return;
  const colors = ["#E11D48", "#2563EB", "#F59E0B", "#16A34A", "#7C3AED", "#0284C7", "#DB2777", "#EA580C"];
  const N = 36;
  for (let i = 0; i < N; i++) {
    const c = document.createElement("div");
    const col = colors[i % colors.length];
    c.style.cssText = `
      width: 24px; height: 38px;
      background: ${col};
      border-radius: 12px 12px 4px 4px / 14px 14px 2px 2px;
      position: relative;
      flex: 0 0 auto;
      opacity: .85;
    `;
    c.innerHTML = `
      <span style="position:absolute; top:-12px; left:50%; transform:translateX(-50%); width:14px; height:14px; border-radius:50%; background:#F4C9A5; display:block;"></span>
      <span style="position:absolute; top:6px; left:-6px; width:8px; height:18px; border-radius:4px; background:${col};"></span>
      <span style="position:absolute; top:6px; right:-6px; width:8px; height:18px; border-radius:4px; background:${col};"></span>
    `;
    band.appendChild(c);
  }
})();
